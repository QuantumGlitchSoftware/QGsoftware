This game was made by QuantumGlitchSoftware

Quantumglitchsoftware.github.io

If you are having performance issues, like low fps, sloppy inputs, or anything of that sort, try lowering your resoloution in the launcher.

If that doesn't work, lower th graphics quality too.

Enjoy the demo :D